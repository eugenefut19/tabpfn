
class Config:

    RANDOM_STATE = 42

    DATA_PATH = "healthcare-dataset-stroke-data.csv"

    TARGET_COLUMN = "stroke"

    TEST_SIZE = 0.2

    VALIDATION_SIZE = 0.1

    CONTEXT_ROWS = 1000

    BATCH_SIZE = 100

    MAX_CATEGORIES = 25
