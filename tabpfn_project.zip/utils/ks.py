
import pandas as pd
import numpy as np


def calculate_ks(y_true, probs):

    df = pd.DataFrame({
        "target": y_true,
        "prob": probs,
    })

    df = df.sort_values(
        by="prob",
        ascending=False,
    )

    df["bucket"] = pd.qcut(
        df.index,
        10,
        labels=False,
    )

    grouped = df.groupby("bucket")

    ks_table = grouped["target"].agg(
        bads="sum",
        total="count",
    )

    ks_table["goods"] = (
        ks_table["total"] - ks_table["bads"]
    )

    ks_table["cum_bads"] = (
        ks_table["bads"].cumsum()
        / ks_table["bads"].sum()
    )

    ks_table["cum_goods"] = (
        ks_table["goods"].cumsum()
        / ks_table["goods"].sum()
    )

    ks_table["ks"] = (
        ks_table["cum_bads"]
        - ks_table["cum_goods"]
    ).abs()

    ks_score = ks_table["ks"].max()

    return ks_score, ks_table
