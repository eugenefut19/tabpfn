
import numpy as np


def batch_predict_proba(
    model,
    X,
    batch_size,
):

    predictions = []

    for i in range(0, len(X), batch_size):

        batch = X.iloc[i:i + batch_size]

        probs = model.predict_proba(batch)[:, 1]

        predictions.extend(probs)

    return np.array(predictions)
