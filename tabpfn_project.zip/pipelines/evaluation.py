
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    roc_auc_score,
    f1_score,
)

from utils.batching import batch_predict_proba
from utils.ks import calculate_ks


def evaluate_model(
    model,
    X,
    y,
    threshold,
    model_name,
    batch_size=None,
    calibrator=None,
):

    if batch_size is not None:

        probs = batch_predict_proba(
            model,
            X,
            batch_size,
        )

    else:

        probs = model.predict_proba(X)[:, 1]

    if calibrator is not None:

        probs = calibrator.transform(probs)

    preds = (probs >= threshold).astype(int)

    ks_score, _ = calculate_ks(
        y,
        probs,
    )

    metrics = {
        "model": model_name,
        "accuracy": accuracy_score(y, preds),
        "precision": precision_score(y, preds, zero_division=0),
        "recall": recall_score(y, preds, zero_division=0),
        "f1": f1_score(y, preds, zero_division=0),
        "roc_auc": roc_auc_score(y, probs),
        "ks": ks_score,
    }

    return {
        "metrics": metrics,
        "probs": probs,
    }


def print_results(results_df):

    print("\nMODEL RESULTS")
    print("-" * 80)

    print(results_df)
