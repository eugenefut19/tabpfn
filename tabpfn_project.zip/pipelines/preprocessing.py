
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder


def build_preprocessor(X_train, max_categories):

    categorical_cols = X_train.select_dtypes(
        include=["object", "category"]
    ).columns.tolist()

    preprocessor = ColumnTransformer(
        transformers=[
            (
                "cat",
                OneHotEncoder(
                    sparse_output=False,
                    handle_unknown="ignore",
                    max_categories=max_categories,
                ),
                categorical_cols,
            )
        ],
        remainder="passthrough",
    )

    return preprocessor
