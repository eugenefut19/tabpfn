
import numpy as np

from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import f1_score

from utils.batching import batch_predict_proba


def calibrate_probabilities(
    model,
    X_val,
    y_val,
    batch_size,
):

    probs_raw = batch_predict_proba(
        model,
        X_val,
        batch_size,
    )

    calibrator = IsotonicRegression(
        out_of_bounds="clip"
    )

    calibrator.fit(
        probs_raw,
        y_val,
    )

    calibrated_probs = calibrator.transform(
        probs_raw
    )

    return calibrated_probs, calibrator


def find_best_threshold(y_true, probs):

    best_threshold = 0.5
    best_f1 = -1

    for threshold in np.arange(0.01, 0.50, 0.01):

        preds = (probs >= threshold).astype(int)

        f1 = f1_score(
            y_true,
            preds,
            zero_division=0,
        )

        if f1 > best_f1:

            best_f1 = f1
            best_threshold = threshold

    return best_threshold
